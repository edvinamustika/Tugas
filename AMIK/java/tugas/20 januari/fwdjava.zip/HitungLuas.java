class HitungLuas{
	public static int luasPersegiPanjang(int p, int l){
		return p*l;
	}
	public static void main(String args){
		luasPersegiPanjang();
	}
}